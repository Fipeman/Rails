class Story < ApplicationRecord
end
