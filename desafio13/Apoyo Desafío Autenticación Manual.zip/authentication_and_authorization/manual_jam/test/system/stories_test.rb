require "application_system_test_case"

class StoriesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit stories_url
  #
  #   assert_selector "h1", text: "Story"
  # end
end
